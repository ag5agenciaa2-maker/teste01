
import React from 'react';
import { MessageSquare, ClipboardCheck, Lightbulb, FileText } from 'lucide-react';

const steps = [
  {
    icon: <MessageSquare size={28} />,
    title: "Contato Inicial",
    desc: "Você entra em contato e descreve sua necessidade. Eu informo quais documentos e dados são importantes para a análise."
  },
  {
    icon: <ClipboardCheck size={28} />,
    title: "Análise Detalhada",
    desc: "Análise do seu histórico de contribuições e documentos do INSS para identificar requisitos, pendências e caminhos possíveis."
  },
  {
    icon: <Lightbulb size={28} />,
    title: "Estratégia",
    desc: "Definição da melhor estratégia para o seu caso, com explicação clara de riscos, prazos e próximos passos."
  },
  {
    icon: <FileText size={28} />,
    title: "Acompanhamento",
    desc: "Acompanhamento do pedido administrativo e, quando cabível, medidas judiciais, sempre com responsabilidade e transparência."
  }
];

const HowItWorks: React.FC = () => {
  return (
    <section className="py-24 bg-olive-950 text-white overflow-hidden relative">
      <div className="absolute top-0 left-0 w-full h-full opacity-5 pointer-events-none">
        <div className="grid grid-cols-12 h-full">
           {[...Array(12)].map((_, i) => (
             <div key={i} className="border-r border-olive-400 h-full"></div>
           ))}
        </div>
      </div>
      
      <div className="container mx-auto px-4 md:px-8 relative z-10">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-serif font-bold mb-4">Como posso te ajudar passo a passo</h2>
          <div className="w-20 h-1 bg-gold-500 mx-auto"></div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {steps.map((step, idx) => (
            <div key={idx} className="relative group p-8 rounded-2xl bg-white/5 border border-white/10 hover:bg-white/10 transition-all subtle-lift">
              <div className="absolute -top-4 -left-4 w-10 h-10 bg-gold-500 rounded-xl flex items-center justify-center text-olive-950 font-bold shadow-lg">
                {idx + 1}
              </div>
              <div className="text-gold-400 mb-6 group-hover:scale-110 transition-transform">
                {step.icon}
              </div>
              <h3 className="text-xl font-serif font-bold mb-3">{step.title}</h3>
              <p className="text-olive-200 text-sm leading-relaxed opacity-80 group-hover:opacity-100">{step.desc}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default HowItWorks;
