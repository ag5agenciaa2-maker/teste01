import React from 'react';
import { CheckCircle, ArrowRight, Gavel } from 'lucide-react';
import { WHATSAPP_LINK, ASSETS } from '../constants.ts';

const Hero: React.FC = () => {
  return (
    <section id="inicio" className="relative min-h-[60vh] flex items-center overflow-hidden bg-white pt-28 pb-14">
      <div className="absolute top-0 right-0 w-1/2 h-full bg-olive-50/40 -z-10 rounded-l-[120px] hidden lg:block"></div>
      
      <div className="container mx-auto px-4 md:px-8 relative z-10">
        <div className="flex flex-col lg:flex-row items-center gap-12 lg:gap-16">
          <div className="flex-1 text-center lg:text-left">
            <div className="inline-flex items-center gap-2 bg-gold-100 text-gold-800 border border-gold-200 px-4 py-1.5 rounded-full text-[10px] md:text-xs font-bold tracking-[0.15em] uppercase mb-8">
              <span className="w-2 h-2 bg-gold-500 rounded-full animate-pulse"></span>
              Atendimento em Campo Grande – RJ
            </div>
            
            <h1 className="text-4xl md:text-5xl lg:text-6xl text-olive-950 font-serif font-bold leading-[1.15] mb-6 text-balance">
              Advogada Previdenciária em <br />
              <span className="text-gold-700">Campo Grande (RJ)</span>
            </h1>
            
            <p className="text-lg md:text-xl text-gray-900 mb-10 max-w-xl mx-auto lg:mx-0 leading-relaxed font-bold">
              Orientação jurídica em aposentadorias, benefícios do INSS e planejamento previdenciário, com atendimento online e humanizado.
            </p>
            
            <div className="flex flex-col gap-4 mb-10 max-w-md mx-auto lg:mx-0">
              {[
                "Análise detalhada do tempo de contribuição",
                "Planejamento previdenciário estratégico",
                "Atuação rápida em pedidos negados pelo INSS"
              ].map((item, idx) => (
                <div key={idx} className="flex items-center gap-3 text-left">
                  <CheckCircle className="text-gold-700 shrink-0" size={22} />
                  <span className="text-gray-900 font-bold text-base md:text-lg">{item}</span>
                </div>
              ))}
            </div>

            <div className="hero-buttons-container flex flex-col sm:flex-row gap-5 justify-center lg:justify-start">
              <a 
                href={WHATSAPP_LINK}
                className="bg-olive-600 text-white px-10 py-4 rounded-full text-lg font-bold hover:bg-olive-700 transition-all shadow-xl shadow-olive-200 flex items-center justify-center gap-3 group active:scale-95 h-[60px]"
              >
                Falar no WhatsApp
                <ArrowRight className="group-hover:translate-x-1 transition-transform" />
              </a>
              <a 
                href="#servicos"
                className="bg-white text-olive-900 border-2 border-olive-100 px-10 py-4 rounded-full text-lg font-bold hover:bg-olive-50 transition-all flex items-center justify-center active:scale-95 h-[60px]"
              >
                Ver serviços
              </a>
            </div>
          </div>

          <div className="flex-1 w-full max-w-md lg:max-w-lg">
            <div className="relative">
              <div className="relative z-10 p-2">
                <div className="legal-blob overflow-hidden aspect-square border-4 border-olive-100 shadow-2xl relative group bg-white">
                  <img 
                    src={ASSETS.legalSymbol} 
                    alt="Símbolo da justiça representando direito previdenciário e benefícios do INSS" 
                    width="500"
                    height="500"
                    fetchpriority="high"
                    className="w-full h-full object-cover transition-all duration-700 hover:scale-105"
                  />
                  <div className="absolute inset-0 bg-olive-900/5 group-hover:bg-transparent transition-colors"></div>
                </div>
              </div>

              <div className="absolute -bottom-6 -left-6 lg:-left-12 bg-white p-5 rounded-2xl shadow-2xl z-20 flex items-center gap-4 border-l-4 border-gold-500 subtle-lift">
                <div className="p-3 bg-olive-50 rounded-full text-olive-700">
                  <Gavel size={24} />
                </div>
                <div>
                  <p className="text-olive-950 font-bold text-sm leading-tight">OAB/RJ Ativa</p>
                  <p className="text-gray-700 text-[11px] font-bold uppercase tracking-wider">Compromisso Ético</p>
                </div>
              </div>
              <div className="absolute -top-10 -right-10 w-40 h-40 bg-gold-200/30 rounded-full blur-3xl -z-10"></div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;