import React from 'react';
import { Award, ShieldCheck, Star, Users } from 'lucide-react';
import { ASSETS } from '../constants';

const Authority: React.FC = () => {
  return (
    <section className="py-24 bg-white">
      <div className="container mx-auto px-4 md:px-8">
        <div className="flex flex-col lg:flex-row items-center gap-16">
          <div className="flex-1 space-y-8">
            <div className="inline-flex items-center gap-2 text-gold-700 font-bold uppercase tracking-[0.3em] text-xs">
              <Award size={20} />
              Reconhecimento Institucional
            </div>
            
            <h2 className="text-3xl md:text-5xl text-olive-950 font-serif font-bold leading-tight">
              Atuação comprometida com o <span className="text-olive-600">Direito Previdenciário</span>
            </h2>
            
            <p className="text-gray-800 text-lg leading-relaxed font-bold">
              Como membro da Comissão de Direito Previdenciário da 29ª Subseção da OAB/RJ, atuo com foco técnico em demandas previdenciárias, buscando orientar beneficiários do INSS com clareza e responsabilidade, especialmente em Campo Grande e região.
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
              <div className="p-6 bg-olive-50 rounded-2xl border-l-4 border-gold-500 shadow-sm">
                <Users className="text-olive-700 mb-3" size={24} />
                <p className="text-olive-950 font-bold">Membro da Comissão</p>
                <p className="text-gray-700 text-sm font-bold">29ª Subseção OAB/RJ</p>
              </div>
              <div className="p-6 bg-olive-50 rounded-2xl border-l-4 border-gold-500 shadow-sm">
                <ShieldCheck className="text-olive-700 mb-3" size={24} />
                <p className="text-olive-950 font-bold">Ética e Segurança</p>
                <p className="text-gray-700 text-sm font-bold">Registro OAB Ativo</p>
              </div>
            </div>

            <div className="flex items-center gap-2 text-gold-700">
              {[...Array(5)].map((_, i) => <Star key={i} size={18} fill="currentColor" />)}
              <span className="ml-3 text-olive-950 font-bold text-sm tracking-tight italic">Atuação profissional reconhecida na Zona Oeste</span>
            </div>
          </div>

          <div className="flex-1 w-full">
            <div className="relative group">
              <div className="absolute -inset-4 bg-olive-50 rounded-3xl -z-10 group-hover:scale-105 transition-transform duration-500"></div>
              <img 
                src={ASSETS.authorityInauguration} 
                alt="Foto da Dra. Jéssica Moreira na posse como membro da Comissão de Direito Previdenciário OAB/RJ" 
                width="600"
                height="400"
                loading="lazy"
                className="rounded-2xl shadow-2xl w-full h-auto object-cover border-4 border-white"
              />
              <div className="absolute bottom-6 left-6 right-6 bg-olive-900/95 backdrop-blur-md p-6 rounded-xl border border-white/10 text-white">
                <p className="font-serif font-bold italic text-gold-400">"Um compromisso com a classe e com o cidadão."</p>
                <p className="text-[10px] uppercase tracking-widest mt-2 opacity-80 font-bold">Posse na Comissão de Direito Previdenciário - Campo Grande RJ</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Authority;