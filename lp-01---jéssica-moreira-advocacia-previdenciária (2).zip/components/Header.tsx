import React, { useState, useEffect } from 'react';
import { Menu, X, Phone } from 'lucide-react';
import { NAVIGATION_LINKS, WHATSAPP_LINK, ASSETS } from '../constants.ts';

const Header: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <nav className={`fixed w-full z-50 transition-all duration-300 ${scrolled ? 'bg-white shadow-md py-2' : 'bg-transparent py-4'}`}>
      <div className="container mx-auto px-4 md:px-8 flex justify-between items-center">
        <div className="flex items-center gap-3">
          <img 
            src={ASSETS.logo} 
            alt="Logotipo Jéssica Moreira Advocacia Previdenciária" 
            width="48"
            height="48"
            className="h-10 w-10 md:h-12 md:w-12 rounded-lg object-cover shadow-sm" 
          />
          <div className="flex flex-col">
            <span className="text-lg md:text-xl font-serif font-bold text-olive-900 leading-none tracking-tight">
              JÉSSICA MOREIRA
            </span>
            <span className="text-[9px] md:text-[10px] tracking-[0.2em] uppercase text-gold-700 font-bold">
              Advocacia Previdenciária
            </span>
          </div>
        </div>

        <div className="hidden lg:flex items-center space-x-8">
          {NAVIGATION_LINKS.map((link) => (
            <a
              key={link.href}
              href={link.href}
              className="text-sm font-bold text-olive-900 hover:text-gold-700 transition-colors uppercase tracking-wider"
            >
              {link.label}
            </a>
          ))}
          <a
            href={WHATSAPP_LINK}
            className="bg-olive-600 text-white px-6 py-2.5 rounded-full text-sm font-bold hover:bg-olive-700 transition-all shadow-lg flex items-center gap-2"
          >
            <Phone size={16} />
            Atendimento
          </a>
        </div>

        <button
          className="lg:hidden text-olive-900 p-2"
          onClick={() => setIsOpen(!isOpen)}
          aria-label={isOpen ? "Fechar menu de navegação" : "Abrir menu de navegação"}
        >
          {isOpen ? <X size={28} /> : <Menu size={28} />}
        </button>
      </div>

      <div className={`lg:hidden absolute top-full left-0 w-full bg-white border-t border-gray-100 transition-all duration-300 overflow-hidden ${isOpen ? 'max-h-screen opacity-100 shadow-2xl' : 'max-h-0 opacity-0'}`}>
        <div className="flex flex-col p-6 space-y-4">
          {NAVIGATION_LINKS.map((link) => (
            <a
              key={link.href}
              href={link.href}
              className="text-lg font-bold text-olive-900 py-3 border-b border-olive-50"
              onClick={() => setIsOpen(false)}
            >
              {link.label}
            </a>
          ))}
          <a
            href={WHATSAPP_LINK}
            className="bg-olive-600 text-white text-center py-4 rounded-xl text-lg font-bold mt-4 shadow-lg flex justify-center items-center gap-2"
          >
            <Phone size={20} />
            Falar no WhatsApp
          </a>
        </div>
      </div>
    </nav>
  );
};

export default Header;