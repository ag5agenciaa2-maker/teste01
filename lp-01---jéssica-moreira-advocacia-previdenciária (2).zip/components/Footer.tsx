import React from 'react';
import { Instagram, Mail, MapPin, Phone, MessageCircle } from 'lucide-react';
import { CONTACT_INFO, NAVIGATION_LINKS, WHATSAPP_LINK, ASSETS } from '../constants';

const Footer: React.FC = () => {
  return (
    <footer id="contato" className="bg-olive-950 text-white pt-24 pb-12 border-t border-white/5">
      <div className="container mx-auto px-4 md:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 mb-20">
          {/* Column 1: Logo & About */}
          <div className="space-y-8">
            <div className="flex items-center gap-4">
              <img 
                src={ASSETS.logo} 
                alt="Jéssica Moreira Advocacia Previdenciária em Campo Grande RJ" 
                className="h-16 w-16 rounded-xl border border-white/10 shadow-lg" 
              />
              <div>
                <span className="text-xl font-serif font-bold block leading-tight tracking-tight">JÉSSICA MOREIRA</span>
                <span className="text-[10px] tracking-widest uppercase text-gold-500 font-bold">Advocacia Previdenciária</span>
              </div>
            </div>
            <p className="text-olive-100 text-sm leading-relaxed opacity-90">
              Especialista em garantir direitos previdenciários com ética, transparência e atendimento individualizado em Campo Grande e Zona Oeste do RJ.
            </p>
            <div className="flex gap-4">
              <a 
                href={`https://instagram.com/jessica.moreira.adv`} 
                target="_blank" 
                rel="noopener noreferrer" 
                className="p-3 bg-white/5 hover:bg-gold-500 hover:text-olive-950 rounded-full transition-all border border-white/10"
                aria-label="Siga nosso perfil no Instagram"
              >
                <Instagram size={20} />
              </a>
              <a 
                href={WHATSAPP_LINK} 
                target="_blank" 
                rel="noopener noreferrer" 
                className="p-3 bg-white/5 hover:bg-gold-500 hover:text-olive-950 rounded-full transition-all border border-white/10"
                aria-label="Fale conosco pelo WhatsApp"
              >
                <MessageCircle size={20} />
              </a>
            </div>
          </div>

          {/* Column 2: Navigation */}
          <div className="space-y-8">
            <h3 className="text-sm font-bold text-gold-500 uppercase tracking-[0.3em]">Navegação</h3>
            <ul className="space-y-4 text-sm text-olive-100">
              {NAVIGATION_LINKS.map((link) => (
                <li key={link.href}>
                  <a href={link.href} className="hover:text-gold-500 transition-colors flex items-center gap-3 group">
                    <span className="w-1 h-1 bg-gold-500 rounded-full group-hover:scale-150 transition-transform"></span>
                    {link.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Column 3: Contact */}
          <div className="space-y-8">
            <h3 className="text-sm font-bold text-gold-500 uppercase tracking-[0.3em]">Contato Direto</h3>
            <ul className="space-y-5 text-sm text-olive-100">
              <li className="flex items-start gap-4">
                <MapPin className="text-gold-500 shrink-0 mt-1" size={20} />
                <span className="leading-relaxed opacity-90">{CONTACT_INFO.address}</span>
              </li>
              <li className="flex items-center gap-4">
                <Phone className="text-gold-500 shrink-0" size={20} />
                <span className="opacity-90">{CONTACT_INFO.phone}</span>
              </li>
              <li className="flex items-center gap-4">
                <Mail className="text-gold-500 shrink-0" size={20} />
                <span className="opacity-90 truncate">{CONTACT_INFO.email}</span>
              </li>
            </ul>
          </div>

          {/* Column 4: Local SEO / Areas */}
          <div className="space-y-8">
            <h3 className="text-sm font-bold text-gold-500 uppercase tracking-[0.3em]">Localização Estratégica</h3>
            <div className="space-y-4">
              <p className="text-sm text-olive-100 leading-relaxed italic opacity-90">
                Atendimento online para todo o Brasil, com base administrativa em Campo Grande (Zona Oeste do RJ).
              </p>
              <div className="bg-white/5 p-4 rounded-xl border border-white/10">
                <p className="text-[10px] text-olive-300 uppercase tracking-widest font-bold mb-2">Horário Comercial</p>
                <p className="text-sm text-white font-medium">Segunda a Sexta: 09h às 18h</p>
              </div>
            </div>
          </div>
        </div>

        {/* Legal bar */}
        <div className="border-t border-white/5 pt-12 flex flex-col md:flex-row justify-between items-center gap-6 text-[10px] uppercase tracking-widest text-olive-300 font-bold">
          <p>© {new Date().getFullYear()} {CONTACT_INFO.name}. Todos os direitos reservados.</p>
          <div className="flex items-center gap-2">
             <span>Design & Estratégia por</span>
             <a href="https://www.ag5agencia.com.br/" target="_blank" rel="noopener noreferrer" className="text-gold-500 hover:text-white transition-colors">
               AG5 Agência
             </a>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;