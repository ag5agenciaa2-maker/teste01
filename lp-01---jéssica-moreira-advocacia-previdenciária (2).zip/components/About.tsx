import React from 'react';
import { ASSETS } from '../constants';

const About: React.FC = () => {
  return (
    <section id="sobre" className="py-24 bg-olive-900 text-white relative overflow-hidden">
      <div className="absolute -right-20 -top-20 opacity-5 select-none pointer-events-none">
        <img src={ASSETS.logo} alt="" width="384" height="384" className="w-96 h-96 grayscale invert" aria-hidden="true" />
      </div>

      <div className="container mx-auto px-4 md:px-8">
        <div className="flex flex-col md:flex-row items-center gap-16">
          <div className="w-full md:w-1/2 lg:w-2/5 order-2 md:order-1">
            <div className="relative inline-block">
              <div className="absolute -top-6 -left-6 w-full h-full border-2 border-gold-500/30 rounded-3xl -z-10"></div>
              <img 
                src={ASSETS.lawyerHero} 
                alt="Retrato profissional da Dra. Jéssica Moreira, Advogada Previdenciária" 
                width="480"
                height="600"
                loading="lazy"
                className="w-full h-auto rounded-3xl shadow-2xl object-cover bg-olive-800"
              />
            </div>
          </div>
          
          <div className="w-full md:w-1/2 lg:w-3/5 order-1 md:order-2 space-y-8">
            <span className="text-gold-500 font-bold tracking-[0.4em] uppercase text-xs">A Advogada</span>
            <h2 className="text-4xl md:text-5xl font-serif font-bold text-white">Jéssica Moreira</h2>
            <div className="w-20 h-1 bg-gold-500"></div>
            
            <div className="space-y-6 text-olive-50 text-lg leading-relaxed">
              <p className="font-medium">
                Advogada com atuação em Direito Previdenciário, com foco em planejamento previdenciário, aposentadorias e benefícios do INSS, com atendimento online e suporte individualizado.
              </p>
              <p className="font-medium">
                O trabalho é baseado na análise do histórico contributivo e documentação para orientar o melhor caminho administrativo e, quando necessário, judicial, de forma ética e técnica.
              </p>
              <p className="italic opacity-90 font-medium">
                "Minha missão é orientar com clareza para que você compreenda seus direitos e tome decisões com mais segurança."
              </p>
            </div>
            
            <div className="grid grid-cols-2 gap-8 pt-8 border-t border-white/10">
               <div>
                 <p className="text-3xl font-serif font-bold text-gold-500">Campo Grande</p>
                 <p className="text-[10px] text-olive-300 uppercase tracking-widest font-bold">Base de Atendimento</p>
               </div>
               <div>
                 <p className="text-3xl font-serif font-bold text-gold-500">OAB Ativa</p>
                 <p className="text-[10px] text-olive-300 uppercase tracking-widest font-bold">Registro RJ</p>
               </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default About;