
import React from 'react';
import { WHATSAPP_LINK } from '../constants';

const FinalCTA: React.FC = () => {
  return (
    <section className="py-20 bg-white">
      <div className="container mx-auto px-4 md:px-8">
        <div className="bg-gradient-to-br from-olive-800 to-olive-950 rounded-[2.5rem] p-10 md:p-20 text-center text-white relative overflow-hidden shadow-2xl">
          {/* Decorative shapes */}
          <div className="absolute top-0 right-0 w-64 h-64 bg-gold-500/10 rounded-full -translate-y-1/2 translate-x-1/2"></div>
          <div className="absolute bottom-0 left-0 w-48 h-48 bg-white/5 rounded-full translate-y-1/2 -translate-x-1/2"></div>
          
          <div className="relative z-10 max-w-3xl mx-auto">
            <h2 className="text-3xl md:text-5xl font-serif font-bold mb-8 leading-tight">
              Planeje seu futuro previdenciário com mais segurança e tranquilidade
            </h2>
            <p className="text-xl text-olive-100 mb-12 opacity-90">
              Receba orientação jurídica clara e personalizada para tomar decisões conscientes sobre sua aposentadoria ou benefício do INSS.
            </p>
            <a 
              href={WHATSAPP_LINK}
              className="inline-block bg-gold-500 text-gold-950 px-10 py-5 rounded-full text-xl font-bold hover:bg-gold-400 transition-all shadow-xl hover:-translate-y-1"
            >
              Falar com a advogada no WhatsApp
            </a>
            <p className="mt-8 text-olive-300 text-sm italic">
              *Atendimento focado em soluções administrativas e judiciais.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
};

export default FinalCTA;
