import React from 'react';
import { Calendar, Users, HardHat, Heart, Scale } from 'lucide-react';

const services = [
  {
    icon: <Calendar className="text-gold-600" />,
    title: "Planejamento Previdenciário",
    desc: "Análise do histórico contributivo e documentação para orientar o melhor momento e a melhor estratégia de aposentadoria, com foco preventivo e organizado."
  },
  {
    icon: <Users className="text-gold-600" />,
    title: "Aposentadorias",
    desc: "Orientação e condução de pedidos de aposentadoria conforme seu perfil (idade, tempo de contribuição e regras aplicáveis), com conferência de vínculos e documentos."
  },
  {
    icon: <HardHat className="text-gold-600" />,
    title: "Aposentadoria Especial",
    desc: "Atuação em casos com exposição a agentes nocivos, com análise de documentos como PPP e laudos, quando aplicável, para avaliar possibilidade de enquadramento."
  },
  {
    icon: <Heart className="text-gold-600" />,
    title: "Benefícios do INSS",
    desc: "Atuação em benefícios como BPC/LOAS, pensão por morte, salário-maternidade e benefícios por incapacidade, com orientação documental e acompanhamento do pedido."
  },
  {
    icon: <Scale className="text-gold-600" />,
    title: "Atuação Admin. e Judicial",
    desc: "Condução de requerimentos, recursos e, quando cabível, medidas judiciais, com foco técnico, transparência e responsabilidade no andamento do caso."
  }
];

const Services: React.FC = () => {
  return (
    <section id="servicos" className="py-24 bg-gray-50">
      <div className="container mx-auto px-4 md:px-8">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <span className="text-gold-600 font-bold tracking-widest uppercase text-xs mb-3 block">Excelência Jurídica</span>
          <h2 className="text-3xl md:text-4xl text-olive-950 font-serif font-bold mb-6">Serviços em Direito Previdenciário</h2>
          <p className="text-gray-800 font-medium">Atuação em demandas previdenciárias administrativas e judiciais, com foco em planejamento de aposentadoria, aposentadoria especial e benefícios do INSS, conforme o seu histórico de contribuição e documentação.</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {services.map((item, idx) => (
            <div key={idx} className="bg-white p-8 rounded-2xl subtle-lift shadow-sm group border border-transparent hover:border-gold-500/20">
              <div className="mb-6 p-4 bg-olive-50 rounded-xl inline-block group-hover:bg-gold-50 transition-colors">
                {item.icon}
              </div>
              <h3 className="text-xl font-serif font-bold text-olive-900 mb-4">{item.title}</h3>
              <p className="text-gray-800 leading-relaxed text-sm">
                {item.desc}
              </p>
            </div>
          ))}
          {/* Last block as a Call to Action */}
          <div className="bg-olive-800 p-8 rounded-2xl subtle-lift shadow-lg flex flex-col justify-center items-center text-center text-white">
            <h3 className="text-2xl font-serif font-bold mb-4">Tem outra dúvida?</h3>
            <p className="text-olive-100 text-sm mb-6">Cada caso é único. Entre em contato para uma análise personalizada.</p>
            <a href="#contato" className="bg-gold-500 text-gold-950 px-6 py-3 rounded-full font-bold hover:bg-gold-400 transition-colors shadow-md">Consultar agora</a>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Services;