
import React, { useState } from 'react';
import { ChevronDown, ChevronUp } from 'lucide-react';

const faqData = [
  {
    q: "Quanto tempo falta para eu me aposentar?",
    a: "Depende do seu histórico de contribuições, regras aplicáveis e períodos especiais. A análise normalmente considera CNIS, carteira de trabalho e vínculos, para estimar requisitos e próximos passos."
  },
  {
    q: "Qual o valor do serviço?",
    a: "Os honorários variam conforme o tipo de demanda (planejamento, pedido administrativo, recurso ou ação judicial) e a complexidade do caso. Ao entender sua necessidade, é possível orientar o formato de atuação e os próximos passos."
  },
  {
    q: "Qual é o melhor benefício para mim?",
    a: "A escolha depende do seu perfil e documentação: tipo de aposentadoria, tempo de contribuição, idade e possibilidade de enquadramento em regras específicas. A orientação é feita após análise do histórico e dos documentos."
  },
  {
    q: "O atendimento é online?",
    a: "Sim. O atendimento pode ser realizado de forma online, com envio de documentos e orientações por canais digitais, mantendo acompanhamento do caso conforme necessário."
  },
  {
    q: "Quais documentos preciso separar para a análise?",
    a: "Em geral: CNIS, documento de identidade, comprovante de residência, carteira de trabalho e documentos específicos conforme o pedido (ex.: laudos/PPP em aposentadoria especial)."
  },
  {
    q: "Vocês atendem Campo Grande e Zona Oeste?",
    a: "A atuação tem base em Campo Grande (Zona Oeste do RJ), com atendimento online para outras localidades."
  }
];

const FAQ: React.FC = () => {
  const [openIndex, setOpenIndex] = useState<number | null>(null);

  return (
    <section id="faq" className="py-24 bg-white">
      <div className="container mx-auto px-4 md:px-8 max-w-3xl">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl text-olive-950 font-serif font-bold mb-4">Dúvidas frequentes</h2>
          <p className="text-gray-900 font-medium">Esclareça os principais pontos sobre seus direitos e nosso atendimento.</p>
        </div>

        <div className="space-y-4">
          {faqData.map((item, idx) => (
            <div key={idx} className="border border-olive-100 rounded-2xl overflow-hidden hover:border-olive-300 transition-colors bg-white">
              <button
                className="w-full flex justify-between items-center p-6 text-left hover:bg-olive-50 transition-colors"
                onClick={() => setOpenIndex(openIndex === idx ? null : idx)}
                aria-expanded={openIndex === idx}
              >
                <span className="text-olive-950 font-bold pr-4 text-base md:text-lg">{item.q}</span>
                <div className="shrink-0 text-olive-500">
                  {openIndex === idx ? <ChevronUp /> : <ChevronDown />}
                </div>
              </button>
              
              {/* Resposta sempre no DOM para SEO, ocultada via Grid Rows Transition */}
              <div 
                className={`grid transition-all duration-300 ease-in-out ${
                  openIndex === idx ? 'grid-rows-[1fr] opacity-100' : 'grid-rows-[0fr] opacity-0'
                }`}
              >
                <div className="overflow-hidden">
                  <div className="p-6 bg-olive-50 border-t border-olive-100 text-gray-900 leading-relaxed font-medium">
                    {item.a}
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default FAQ;
