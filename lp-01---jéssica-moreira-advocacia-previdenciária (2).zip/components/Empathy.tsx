
import React from 'react';
import { HelpingHand } from 'lucide-react';

const Empathy: React.FC = () => {
  return (
    <section className="py-20 bg-white">
      <div className="container mx-auto px-4 md:px-8 max-w-4xl text-center">
        <div className="inline-block p-3 bg-olive-50 rounded-full mb-6">
          <HelpingHand className="text-olive-600" size={32} />
        </div>
        <h2 className="text-3xl md:text-4xl text-olive-950 font-serif font-bold mb-8">
          Aposentadoria e benefícios do INSS em Campo Grande (RJ): por onde começar
        </h2>
        <div className="space-y-6 text-lg text-gray-800 leading-relaxed">
          <p>
            Muitas dúvidas surgem na hora de pedir um benefício: requisitos, documentos e regras que mudam conforme o seu histórico. Uma análise correta ajuda a evitar indeferimentos e retrabalho.
          </p>
          <p className="font-bold text-olive-900">
            Você recebe orientação jurídica objetiva para entender opções, documentos e próximos passos, com atendimento online e foco na sua realidade.
          </p>
        </div>
      </div>
    </section>
  );
};

export default Empathy;
